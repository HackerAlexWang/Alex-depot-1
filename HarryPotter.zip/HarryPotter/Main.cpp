#include<time.h>
#include<vector> 
#include<conio.h>
#include<fstream>
#include<iostream>
#include<direct.h>
#include<windows.h>

using namespace std;

struct PINF{
	string name;
	int level;
};

void Start();
void SingleGame();
void NetGame();
void CreateNewCharacter();
void Gotoxy(int x,int y);
void SetNowCursor(bool f);
void Color(int color);

void Start(){
	SetNowCursor(false);
	system("mode con cols=90 lines=30");
	cout<<"              ##      ##    ########    #########    #########    ##      ##"<<endl;
	cout<<"              ##      ##   ##      ##   ##      ##   ##      ##    ##    ## "<<endl;
	cout<<"              ##      ##   ##      ##   ##      ##   ##      ##     ##  ##  "<<endl;
	cout<<"              ##########   ##########  VERSION 1.0.1 #########        ##    "<<endl;
	cout<<"              ##      ##   ##      ##   ##    ##     ##    ##         ##    "<<endl;
	cout<<"              ##      ##   ##      ##   ##     ##    ##     ##        ##    "<<endl;
	cout<<"              ##      ##   ##      ##   ##      ##   ##      ##       ##    "<<endl;
	cout<<endl;
	cout<<"       #########     ########    ##########   ##########   ##########   ######### "<<endl;
	cout<<"       ##      ##   ##      ##       ##           ##       ##           ##      ##"<<endl;
	cout<<"       ##      ##   ##      ##       ##           ##       ##           ##      ##"<<endl;
	cout<<"       #########    ##      ##       ##           ##       ##########   ######### "<<endl;
	cout<<"       ##           ##      ##       ##           ##       ##           ##    ##  "<<endl;
	cout<<"       ##           ##      ##       ##           ##       ##           ##     ## "<<endl;
	cout<<"       ##            ########        ##           ##       ##########   ##      ##"<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<"                                       Loading..."<<endl;
	cout<<"      ____________________________________________________________________________"<<endl;
	int load=0;
	while(load!=76){
		load+=(rand()%(76-load)+1);
		Gotoxy(19,6);
		for(int i=0;i<load;i++)cout<<"=";
		Sleep(1500);
	}
	Gotoxy(18,0);
	cout<<"                                     ______________                                "<<endl;
	cout<<"                                    |   ��һ���   |                               "<<endl;
	cout<<"                                    |____TAB  S____|                               "<<endl;
	cout<<"                                     ______________                                "<<endl;
	cout<<"                                    |   ������Ϸ   |                               "<<endl;
	cout<<"                                    |____TAB  N____|                               "<<endl;
	cout<<"                                     ______________                                "<<endl;
	cout<<"                                    |     �˳�     |                               "<<endl;
	cout<<"                                    |____TAB  E____|                               "<<endl;
	char ch=getch();
	if(ch=='s')SingleGame();
	if(ch=='n')NetGame();
}
void SingleGame(){
	system("cls");
	cout<<"                                       HARRY POTTER                                   "<<endl;
	cout<<"                                         ��һ���                                     "<<endl;
	cout<<"        _________________________________________________________________________     "<<endl;
	cout<<"       |  ѡ������  |                                   | �½�����(0) | �˳�(-1) |    "<<endl;
	cout<<"       |____________|___________________________________|_____________|__________|    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |                                                                         |    "<<endl;
	cout<<"       |_________________________________________________________________________|    "<<endl;
	cout<<endl;
	ifstream pl("./Save/GSys/GameInf.gsys");
	vector<PINF>PlayerList;
	while(!pl.eof()){
		PINF x;
		pl>>x.name>>x.level;
		PlayerList.push_back(x);
	}
	pl.close();
	int ppl=PlayerList.size();
	for(int i=0;i<min(ppl,20);i++){
		Gotoxy(5+i,12);
		cout<<i+1<<"."<<PlayerList[i].name<<" Lv."<<PlayerList[i].level<<endl;
	}
	for(int i=20;i<min(ppl,40);i++){
		Gotoxy(5+i-20,50);
		cout<<i+1<<"."<<PlayerList[i].name<<" Lv."<<PlayerList[i].level<<endl;
	}
	int num;
	while(true){
		Gotoxy(27,0);
		cout<<"       ��ѡ��:";
		SetNowCursor(true);
		cin>>num;
		SetNowCursor(false);
		if(num>=ppl||num<-1)cout<<"      ��������ȷ��Ϣ."<<endl;
		else break;
	}
	if(num==0){
		CreateNewCharacter(); 
	}else if(num==-1)return;
	else{
		
	}
}
void NetGame(){
	
}
void CreateNewCharacter(){
	system("cls");
	cout<<"                                       HARRY POTTER                                   "<<endl;
	cout<<"                                         �½�����                                     "<<endl;
	cout<<"                         ______________           ______________                      "<<endl;
	cout<<"                         |            |           |            |                      "<<endl;
	cout<<"                         | HARRY      |           | VOLDEMORT  |                      "<<endl;
	cout<<"                         |    POTTER  |           |            |                      "<<endl;
	cout<<"                         |            |           |    TEAMS   |                      "<<endl;
	cout<<"                         |    TEAMS   |           |            |                      "<<endl;
	cout<<"                         |  INPUT 1   |           |  INPUT 2   |                      "<<endl;
	cout<<"                         \\            /           \\            /                      "<<endl;
	cout<<"                          \\__________/             \\__________/                       "<<endl;
	cout<<"                               ��ѡ�������Ӫ:";
	int team=0;
	SetNowCursor(true);
	while(true){
		Gotoxy(11,46);
		cin>>team;
		if(team<1||team>2)cout<<"                               ����ʧ��.����������."<<endl;
		else break;
	}
	Gotoxy(12,0);
	cout<<"                               �������������:"<<endl;
	Color(12);
	cout<<"                           �ɴ�Сд��ĸ��������ɣ����ð��������ַ���������10���ַ�����";
	string name;
	Color(15);
	while(true){
		Gotoxy(12,46);
		cin>>name;
		bool f=true;
		if(name.size()>10)f=false;
		for(int i=0;i<name.size();i++){
			if((name[i]>='a'&&name[i]<='z')||(name[i]>='A'&&name[i]<='Z')||(name[i]>='0'&&name[i]<='9')){}
			else{
				f=false;
				break;
			}
		}
		if(!f){
			Gotoxy(14,0);
			cout<<"                               ����������."<<endl;
		}
		else break;
	}
	system("cls");
	SetNowCursor(false);
	cout<<"                                       HARRY POTTER                                   "<<endl;
	cout<<"                                         �½�����                                     "<<endl;
	cout<<"                                       �����½�...                                    "<<endl;
	cout<<"                   __________________________________________________                 "<<endl;
	PINF NewUser;
	NewUser.name=name;
	NewUser.level=1;
	ifstream pl("./Save/GSys/GameInf.gsys");
	vector<PINF>PlayerList;
	while(!pl.eof()){
		PINF x;
		pl>>x.name>>x.level;
		PlayerList.push_back(x);
	}
	pl.close();
	PlayerList.push_back(NewUser);
	fopen("./Save/GSys/GameInf.gsys","w+");
	ofstream pr("./Save/GSys/GameInf.gsys");
	for(int i=0;i<PlayerList.size();i++){
		if(PlayerList[i].name=="")continue;
		pr<<PlayerList[i].name<<" "<<PlayerList[i].level<<endl;
	}
	pr.close();
	Gotoxy(3,19);
	Sleep(1000);
	cout<<">>>>>>>>>>>>>";
	
}
void Gotoxy(int x,int y){
	int xx=0x0b;
	HANDLE hOutput;
	COORD loc;
	loc.X=y;
	loc.Y=x;
	hOutput=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hOutput,loc);
}
void SetNowCursor(bool f){
	HANDLE handle=GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cursor_info;
	GetConsoleCursorInfo(handle,&cursor_info);
	cursor_info.bVisible=f;
	SetConsoleCursorInfo(handle,&cursor_info);
}
void Color(int color){
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),color);
}
int main(){
	srand(time(0));
	Start();
	return 0;
}

